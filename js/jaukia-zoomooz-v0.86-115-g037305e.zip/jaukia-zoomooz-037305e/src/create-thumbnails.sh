#fixme: should update this

python webkit2png.py --filename=imagestack file:///Users/jaukia/Dropbox/zoomooz/gitcodebase/examples/imagestack/index.html?q=zooming -D site/images/thumbnails/. -C --delay=2

python webkit2png.py --filename=isometric file:///Users/jaukia/Dropbox/zoomooz/gitcodebase/examples/isometric/index.html -D site/images/thumbnails/. -C

python webkit2png.py --filename=simple file:///Users/jaukia/Dropbox/zoomooz/gitcodebase/examples/simple/index.html -D site/images/thumbnails/. -C

python webkit2png.py --filename=hierarchy file:///Users/jaukia/Dropbox/zoomooz/gitcodebase/examples/hierarchy/index.html -D site/images/thumbnails/. -C

python webkit2png.py --filename=rootchange file:///Users/jaukia/Dropbox/zoomooz/gitcodebase/examples/rootchange/index.html -D site/images/thumbnails/. -C

python webkit2png.py --filename=svgtree file:///Users/jaukia/Dropbox/zoomooz/gitcodebase/examples/svgtree/index.html -D site/images/thumbnails/. -C
